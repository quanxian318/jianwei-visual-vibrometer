#pragma once

#include <cmath>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "app/state.h"
#include "app/storage.h"
#include "gfx/canvas.h"
#include "gfx/font.h"
#include "measure/depth.h"
#include "measure/session.h"
#include "ui/icons.h"
#include "ui/theme.h"
#include "util/json_util.h"

namespace vm {

enum class Page { kLive = 0, kResult, kVision, kHistory, kDevice, kSettings };
constexpr int kPageCount = 6;

enum class Dialog { kNone, kShutdown, kWifi };

struct Rect {
  int x = 0, y = 0, w = 0, h = 0;
  bool contains(int px, int py) const { return px >= x && py >= y && px < x + w && py < y + h; }
  bool operator==(const Rect& o) const { return x == o.x && y == o.y && w == o.w && h == o.h; }
};

// What touching a region does. Kind "cmd" sends cmd to Application::command();
// the other kinds change UI-local state (see FbUi::dispatch).
struct UiAction {
  std::string kind;
  JsonValue cmd;
  int arg = 0;
  std::string text;
  double nx0 = 0, ny0 = 0, nw = 1, nh = 1;  // "roi": normalised image window shown in the region
  bool isNull() const { return kind.empty(); }
};

struct HitRegion {
  Rect r;
  UiAction a;
  bool enabled = true;
};

// A saved record loaded for the result page.
struct RecordView {
  std::string id;
  bool loaded = false;
  JsonValue rec;
  std::vector<double> t, disp, f, amp;
};

// UI-local state, owned by the UI thread.
struct UiState {
  Page page = Page::kLive;
  Dialog dialog = Dialog::kNone;
  Rect pressed;  // region under the finger, drawn highlighted
  bool pressing = false;
  int historyPage = 0;
  std::string openRecordId;  // result page shows this saved record instead of the latest one
  int visionView = 0;        // 0 = motion magnification, 1 = vibration heat map, 2 = stereo depth
  double probeX = -1, probeY = -1;  // depth probe point (normalised), -1 = none
  int depthRange = 0;               // 0 = automatic, 1..3 = fixed display ranges
  bool liveHeat = false;     // heat-map overlay on the live preview
  std::string toast;
  int64_t toastUntilMs = 0;
  // Wi-Fi dialog
  std::string ssid, password;
  int field = 0;  // 0 = SSID, 1 = password
  bool shift = false, symbols = false, showPassword = false;
};

// Everything one frame shows, gathered by the UI thread before drawing.
struct UiData {
  SystemState s;
  MeasurementEngine::Live live;
  std::shared_ptr<const DepthMap> depth;  // stereo depth, null until the stereo module publishes one
  std::vector<RecordSummary> records;
  RecordView record;
  int64_t nowMs = 0;   // CLOCK_MONOTONIC
  int64_t wallMs = 0;  // CLOCK_REALTIME
  int tzOffsetMin = 480;
};

// Immediate-mode painter: widgets draw themselves and register their touch
// regions in the same call, so what is shown and what reacts cannot differ.
class Ui {
 public:
  Ui(Canvas& canvas, const UiState& state, std::vector<HitRegion>& hits) : c(canvas), st(state), hits_(hits) {}
  Canvas& c;
  const UiState& st;

  void hit(const Rect& r, const UiAction& a, bool enabled = true);
  void block(const Rect& r);  // swallows touches (modal background)
  bool pressed(const Rect& r) const { return st.pressing && st.pressed == r; }

  void card(const Rect& r, uint32_t fill = theme::kCard);
  void cardTitle(const Rect& r, const std::string& title, Icon icon = Icon::kNone);
  void button(const Rect& r, const std::string& label, Icon icon, uint32_t fill, bool enabled, const UiAction& a,
              int fontPx = 22);
  void iconButton(const Rect& r, Icon icon, bool enabled, const UiAction& a, uint32_t fill = theme::kNeutral);
  void chip(const Rect& r, const std::string& label, bool selected, bool enabled, const UiAction& a);
  void toggle(const Rect& r, bool on, bool enabled, const UiAction& a);
  void stepper(const Rect& r, const std::string& value, bool decOk, bool incOk, const UiAction& dec,
               const UiAction& inc);
  int badge(int x, int y, const std::string& text, uint32_t color, bool filled = false, int fontPx = 18);
  void emptyState(const Rect& r, Icon icon, const std::string& title, const std::string& hint);
  void metric(int x, int y, const std::string& label, const std::string& value, const std::string& unit,
              uint32_t valueColor = theme::kText);

 private:
  std::vector<HitRegion>& hits_;
};

// Line chart with nice axis ticks, used by the result and live pages.
struct ChartOptions {
  std::string title, unitX, unitY;
  uint32_t line = theme::kAccent;
  bool symmetric = false;   // y range symmetric around zero
  bool fromZero = false;    // y axis starts at zero (spectra)
  bool fill = false;        // shaded area under the curve
  double markerX = NAN;     // vertical marker (spectral peak)
  std::string markerLabel;
  std::string rightNote;    // text at the top right
};
void drawChart(Canvas& c, const Rect& r, const std::vector<double>& xs, const std::vector<double>& ys,
               const ChartOptions& o);

UiAction cmdAction(const JsonValue& cmd);
UiAction cmdAction(const std::string& name);
inline UiAction cmdAction(const char* name) { return cmdAction(std::string(name)); }
UiAction uiAction(const std::string& kind, int arg = 0, const std::string& text = std::string());
uint32_t levelColor(AlarmLevel l);
std::string fmtNum(double v, int sig = 4);           // %.4g without "-0"
std::string reasonText(const std::string& reason);  // invalid-result reason -> text
std::string errorText(const std::string& code);     // command error -> text
const char* pageTitle(Page p);
// Largest rectangle with the aspect fw:fh inside box, centred.
Rect fitAspect(const Rect& box, int fw, int fh);

void renderUi(Canvas& c, const UiState& st, const UiData& d, std::vector<HitRegion>& hits);
// Topmost region at (x, y); disabled and blocking regions return a null action.
UiAction hitTest(const std::vector<HitRegion>& hits, int x, int y, Rect* region = nullptr);

// Page renderers (ui_pages.cpp, ui_pages2.cpp).
void renderLivePage(Ui& ui, const UiData& d);
void renderResultPage(Ui& ui, const UiData& d);
void renderVisionPage(Ui& ui, const UiData& d);
void renderHistoryPage(Ui& ui, const UiData& d);
void renderDevicePage(Ui& ui, const UiData& d);
void renderSettingsPage(Ui& ui, const UiData& d);
void renderWifiDialog(Ui& ui, const UiData& d);

}  // namespace vm
