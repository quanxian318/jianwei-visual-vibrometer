#pragma once

#include <atomic>
#include <string>
#include <thread>
#include <vector>

#include "app/state.h"
#include "gfx/canvas.h"
#include "measure/session.h"
#include "ui/fb_display.h"
#include "util/json_util.h"

namespace vm {

class Application;

// Touch screen UI (1024x600): camera preview with ROI and display zoom,
// live waveform, last result, status bar and the operator buttons. All
// actions go through Application::command(), the same path as vibmonctl.
class FbUi {
 public:
  explicit FbUi(Application& app) : app_(app) {}
  ~FbUi();
  bool start();
  // Renders one frame without a display (used by the host test).
  // The renderer and touch dispatcher share the same availability rules.
  static bool buttonEnabled(const std::string& id, const SystemState& s);
  static JsonValue tapCommand(int x, int y, const SystemState& s);
  static void render(Canvas& c, const SystemState& s, const MeasurementEngine::Live& live, int64_t nowMs,
                     int tzOffsetMin);

 private:
  struct Button {
    std::string id;
    int x, y, w, h;
  };
  void run();
  void onTap(int x, int y, const SystemState& s);
  static std::vector<Button> buttons();

  Application& app_;
  FbDisplay display_;
  TouchInput touch_;
  Canvas canvas_;
  std::thread thread_;
  std::atomic<bool> running_{false};
};

}  // namespace vm
