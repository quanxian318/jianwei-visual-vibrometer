#pragma once

#include <cstddef>
#include <cstdint>
#include <string>

#include "gfx/canvas.h"

namespace vm {

// Linux framebuffer output (16/24/32 bpp). The HDMI path of the vendor base
// design exposes /dev/fb0 through DRM fbdev emulation.
class FbDisplay {
 public:
  ~FbDisplay();
  bool open(const std::string& device);
  int width() const { return w_; }
  int height() const { return h_; }
  void present(const Canvas& c);

 private:
  int fd_ = -1;
  uint8_t* mem_ = nullptr;
  size_t size_ = 0;
  int w_ = 0, h_ = 0, bpp_ = 0, stride_ = 0;
  int rOff_ = 16, gOff_ = 8, bOff_ = 0, rLen_ = 8, gLen_ = 8, bLen_ = 8;
};

// evdev touchscreen (USB HID multi-touch of the 7inch HDMI LCD (H)).
class TouchInput {
 public:
  ~TouchInput();
  bool open(const std::string& device);  // "auto" scans /dev/input/event*
  void setScreen(int w, int h, bool swapXY, bool invertX, bool invertY);
  int fd() const { return fd_; }
  // Reads pending events; returns true when a touch was released (a tap) at x, y.
  bool readTap(int& x, int& y);

 private:
  bool probe(const std::string& path);
  int fd_ = -1;
  int minX_ = 0, maxX_ = 4095, minY_ = 0, maxY_ = 4095;
  int sw_ = 1024, sh_ = 600;
  bool swap_ = false, invX_ = false, invY_ = false;
  int rawX_ = 0, rawY_ = 0;
  bool down_ = false;
  bool releasePending_ = false;
};

}  // namespace vm
