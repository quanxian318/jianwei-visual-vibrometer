#include "ui/fb_ui.h"

#include <poll.h>

#include <algorithm>
#include <cmath>
#include <cstdio>

#include "app/app.h"
#include "app/report.h"
#include "gfx/font.h"
#include "gfx/plot.h"
#include "util/clock.h"
#include "util/log.h"

namespace vm {

namespace {
constexpr uint32_t kBg = 0x101418, kPanel = 0x1C232B, kText = 0xE8E8E8, kDim = 0x9AA4AE;
constexpr uint32_t kGreen = 0x3CB371, kYellow = 0xF0B020, kRed = 0xE04040, kBlue = 0x4A90E2;
constexpr int kPvX = 8, kPvY = 48, kPvW = 640, kPvH = 360;

std::string wifiText(const std::string& s) {
  if (s == "CONNECTED") return "已连接";
  if (s == "CONNECTING") return "连接中";
  if (s == "DISCONNECTED") return "未连接";
  if (s == "OFF") return "未配置";
  return "未知";
}

uint32_t levelColor(AlarmLevel l) {
  if (l == AlarmLevel::kUnknown) return 0x808080;
  return l == AlarmLevel::kAlarm ? kRed : (l == AlarmLevel::kWarn ? kYellow : kGreen);
}

void button(Canvas& c, int x, int y, int w, int h, const std::string& label, uint32_t color, bool enabled) {
  c.fillRect(x, y, w, h, enabled ? color : 0x3A424A);
  c.rect(x, y, w, h, 0x000000);
  const FontFace& f = fontFace(26);
  drawTextCentered(c, f, x + w / 2, y + (h - f.lineHeight) / 2, label, enabled ? 0xFFFFFF : kDim);
}

// Source rectangle of the preview shown at the current display zoom.
void zoomRect(const SystemState& s, double& x0, double& y0, double& w, double& h) {
  w = 1.0 / s.zoom;
  h = 1.0 / s.zoom;
  x0 = std::max(0.0, std::min(1.0 - w, s.zoomCx - w / 2));
  y0 = std::max(0.0, std::min(1.0 - h, s.zoomCy - h / 2));
}
}  // namespace

std::vector<FbUi::Button> FbUi::buttons() {
  const int x0 = 660, w = 172, h = 76, gap = 8, y0 = 340;
  return {
      {"measure", x0, y0, w, h},
      {"print", x0 + w + gap, y0, w, h},
      {"light", x0, y0 + h + gap, w, h},
      {"mute", x0 + w + gap, y0 + h + gap, w, h},
      {"zoom_reset", x0, y0 + 2 * (h + gap), w, h},
      {"shutdown", x0 + w + gap, y0 + 2 * (h + gap), w, h},
  };
}

bool FbUi::buttonEnabled(const std::string& id, const SystemState& s) {
  if (s.shutdownPrepared) return false;
  const bool capturing = s.measureState == "capturing";
  const bool preview = s.measureState == "preview";
  if (id == "measure") return s.cameraOk && !s.pfail && s.printerState == "idle" && (preview || capturing);
  if (id == "print") return s.last.have && s.last.saved && preview && s.printerState == "idle" && !s.pfail;
  if (id == "light") return (s.lightOn || s.lightAllowed) && s.printerState == "idle" && !s.pfail;
  if (id == "mute") return (s.alarmLevel == AlarmLevel::kWarn || s.alarmLevel == AlarmLevel::kAlarm) && !s.alarmMuted;
  if (id == "zoom_reset") return s.zoom > 1.01;
  return id == "shutdown";
}

void FbUi::render(Canvas& c, const SystemState& s, const MeasurementEngine::Live& live, int64_t nowMs, int tz) {
  const FontFace& f18 = fontFace(18);
  const FontFace& f26 = fontFace(26);
  const FontFace& f40 = fontFace(40);
  c.fill(kBg);
  if (s.shutdownPrepared) {
    drawTextCentered(c, f26, c.width() / 2, c.height() / 2 - 40, "关机", kText);
    drawTextCentered(c, f18, c.width() / 2, c.height() / 2,
                     s.message.empty() ? "等待Linux关机" : s.message, kDim);
    return;
  }

  // Status bar.
  c.fillRect(0, 0, c.width(), 40, s.pfail ? 0x7A1E1E : kPanel);
  int x = drawText(c, f26, 8, 4, "视觉测振仪", kText) + 16;
  const std::string clock = s.timeValid ? formatLocal(realtimeMs(), tz, "%H:%M:%S") : "--:--:--";
  x = drawText(c, f18, x, 10, clock, s.timeValid ? kText : kYellow) + 16;
  x = drawText(c, f18, x, 10, std::string("网络 ") + (s.nanoOnline ? wifiText(s.wifiState) : "协处理器离线"),
               s.nanoOnline ? kText : kYellow) + 16;
  char buf[160];
  snprintf(buf, sizeof(buf), "电源 %.1fV %.2fA", s.power.busV, s.power.currentA);
  x = drawText(c, f18, x, 10, buf, s.powerWarn ? kYellow : kText) + 16;
  x = drawText(c, f18, x, 10, "测点 " + (s.pointId.empty() ? std::string("未选择") : s.pointId), kText) + 16;
  if (s.pfail) drawText(c, f18, x, 10, "掉电预警", 0xFFFFFF);

  // Camera preview with display zoom (never changes the calibration).
  c.fillRect(kPvX, kPvY, kPvW, kPvH, 0x000000);
  if (!live.preview.empty() && live.previewW > 0) {
    double zx, zy, zw, zh;
    zoomRect(s, zx, zy, zw, zh);
    const int sx0 = static_cast<int>(zx * live.previewW), sy0 = static_cast<int>(zy * live.previewH);
    const int sw = std::max(1, static_cast<int>(zw * live.previewW)), sh = std::max(1, static_cast<int>(zh * live.previewH));
    for (int yy = 0; yy < kPvH; ++yy) {
      const int sy = std::min(live.previewH - 1, sy0 + yy * sh / kPvH);
      for (int xx = 0; xx < kPvW; ++xx) {
        const int sx = std::min(live.previewW - 1, sx0 + xx * sw / kPvW);
        const uint32_t v = live.preview[static_cast<size_t>(sy) * live.previewW + sx];
        c.set(kPvX + xx, kPvY + yy, (v << 16) | (v << 8) | v);
      }
    }
    // ROI marker in frame-normalised coordinates.
    auto toScreen = [&](double nx, double ny, int& px, int& py) {
      px = kPvX + static_cast<int>((nx - zx) / zw * kPvW);
      py = kPvY + static_cast<int>((ny - zy) / zh * kPvH);
    };
    int px, py;
    if (s.measureState == "capturing" && live.frameW > 0) {
      int qx, qy;
      toScreen(static_cast<double>(live.roi.x) / live.frameW, static_cast<double>(live.roi.y) / live.frameH, px, py);
      toScreen(static_cast<double>(live.roi.x + live.roi.w) / live.frameW,
               static_cast<double>(live.roi.y + live.roi.h) / live.frameH, qx, qy);
      c.rect(px, py, std::max(2, qx - px), std::max(2, qy - py), kYellow, 2);
    } else {
      toScreen(s.roiCx, s.roiCy, px, py);
      c.fillRect(px - 14, py - 1, 28, 3, kGreen);
      c.fillRect(px - 1, py - 14, 3, 28, kGreen);
    }
  } else {
    drawTextCentered(c, f26, kPvX + kPvW / 2, kPvY + kPvH / 2 - 16, live.cameraOk ? "等待画面" : "相机未就绪", kYellow);
  }
  if (s.zoom > 1.01) {
    snprintf(buf, sizeof(buf), "显示 %.1fx", s.zoom);
    drawText(c, f18, kPvX + kPvW - 110, kPvY + 6, buf, kBlue);
  }
  if (s.measureState == "capturing") {
    snprintf(buf, sizeof(buf), "采集中 %.1f / %.0f s", s.measureElapsedS, s.measureDurationS);
    drawText(c, f26, kPvX + 8, kPvY + 6, buf, kYellow);
  } else if (s.measureState == "analyzing") {
    drawText(c, f26, kPvX + 8, kPvY + 6, "计算中", kBlue);
  }
  if (!s.message.empty()) {
    for (int yy = kPvY + kPvH - 34; yy < kPvY + kPvH; ++yy) {
      for (int xx = kPvX; xx < kPvX + kPvW; ++xx) c.blend(xx, yy, 0x000000, 170);
    }
    drawText(c, f18, kPvX + 8, kPvY + kPvH - 30, s.message, kText);
  }

  // Live displacement.
  PlotStyle ps;
  ps.background = kPanel;
  ps.frame = 0x55606A;
  ps.grid = 0x55606A;
  ps.line = kGreen;
  ps.text = kText;
  ps.symmetric = true;
  std::vector<double> xs, ys;
  for (size_t i = 0; i < live.recent.size(); ++i) {
    xs.push_back(static_cast<double>(i));
    ys.push_back(live.recent[i]);
  }
  drawLinePlot(c, kPvX, 416, kPvW, 176, xs, ys, "实时位移", "px", ps);

  // Last result.
  const int rx = 660, rw = 352;
  c.fillRect(rx, 48, rw, 200, kPanel);
  drawText(c, f18, rx + 8, 52, "最近结果", kDim);
  const ResultSummary& r = s.last;
  if (!r.have) {
    drawText(c, f26, rx + 8, 90, "尚未测量", kDim);
  } else if (!r.valid) {
    drawText(c, f26, rx + 8, 84, "结果无效", kYellow);
    drawText(c, f18, rx + 8, 124, r.reason, kText);
  } else {
    snprintf(buf, sizeof(buf), "%.2f Hz", r.dominantHz);
    drawText(c, f40, rx + 8, 74, buf, kText);
    snprintf(buf, sizeof(buf), "峰峰值 %.4g %s", r.peakToPeak, r.unit.c_str());
    drawText(c, f26, rx + 8, 128, buf, kText);
    snprintf(buf, sizeof(buf), "有效值 %.4g %s", r.rms, r.unit.c_str());
    drawText(c, f18, rx + 8, 166, buf, kText);
    drawText(c, f26, rx + 220, 166, levelText(r.level), levelColor(r.level));
  }
  if (r.have) drawText(c, f18, rx + 8, 222, r.measurementId, kDim);

  // Environment and auxiliary sensors.
  c.fillRect(rx, 254, rw, 80, kPanel);
  if (s.envValid) {
    snprintf(buf, sizeof(buf), "温度 %.1f°C  湿度 %.0f%%", s.tempC, s.rhPercent);
  } else {
    snprintf(buf, sizeof(buf), "温湿度 无数据");
  }
  drawText(c, f18, rx + 8, 260, buf, kText);
  if (s.distanceValid) {
    snprintf(buf, sizeof(buf), "距离 %d mm", s.distanceMm);
  } else {
    snprintf(buf, sizeof(buf), "距离 无效 %s", s.tofNote.c_str());
  }
  drawText(c, f18, rx + 8, 284, buf, kText);
  if (s.tachValid) {
    snprintf(buf, sizeof(buf), "脉冲 %.2f Hz", s.tachHz);
  } else {
    snprintf(buf, sizeof(buf), "转速 无信号");
  }
  drawText(c, f18, rx + 8, 308, buf, kDim);

  // Buttons.
  const bool capturing = s.measureState == "capturing";
  for (const Button& b : buttons()) {
    if (b.id == "measure") {
      button(c, b.x, b.y, b.w, b.h, capturing ? "停止测量" : "开始测量", capturing ? kRed : kGreen,
             buttonEnabled(b.id, s));
    } else if (b.id == "print") {
      button(c, b.x, b.y, b.w, b.h, s.printerState == "idle" ? "打印报告" : "打印中", kBlue,
             buttonEnabled(b.id, s));
    } else if (b.id == "light") {
      button(c, b.x, b.y, b.w, b.h, s.lightOn ? "补光 关" : "补光 开", s.lightOn ? kYellow : 0x50606E,
             buttonEnabled(b.id, s));
    } else if (b.id == "mute") {
      button(c, b.x, b.y, b.w, b.h, "报警静音", 0x50606E, buttonEnabled(b.id, s));
    } else if (b.id == "zoom_reset") {
      button(c, b.x, b.y, b.w, b.h, "缩放复位", 0x50606E, buttonEnabled(b.id, s));
    } else if (b.id == "shutdown") {
      button(c, b.x, b.y, b.w, b.h, "关机", 0x6A2A2A, buttonEnabled(b.id, s));
    }
  }
  (void)nowMs;
}

FbUi::~FbUi() {
  running_ = false;
  if (thread_.joinable()) thread_.join();
}

bool FbUi::start() {
  const AppConfig& cfg = app_.config();
  if (!display_.open(cfg.ui.fbdev)) {
    LOGW("ui", "no framebuffer; touch UI disabled (vibmonctl still works)");
    return false;
  }
  canvas_.resize(display_.width(), display_.height(), kBg);
  if (touch_.open(cfg.ui.touchDev)) {
    touch_.setScreen(display_.width(), display_.height(), cfg.ui.swapXY, cfg.ui.invertX, cfg.ui.invertY);
  } else {
    LOGW("ui", "no touch input device found");
  }
  running_ = true;
  thread_ = std::thread(&FbUi::run, this);
  return true;
}

JsonValue FbUi::tapCommand(int x, int y, const SystemState& s) {
  if (s.shutdownPrepared) return JsonValue();
  JsonValue cmd = JsonValue::makeObject();
  if (x >= kPvX && x < kPvX + kPvW && y >= kPvY && y < kPvY + kPvH) {
    if (s.measureState != "preview") return JsonValue();
    double zx, zy, zw, zh;
    zoomRect(s, zx, zy, zw, zh);
    cmd.set("cmd", "roi");
    cmd.set("x", zx + (x - kPvX) * zw / kPvW);
    cmd.set("y", zy + (y - kPvY) * zh / kPvH);
    return cmd;
  }
  for (const Button& b : buttons()) {
    if (x < b.x || x >= b.x + b.w || y < b.y || y >= b.y + b.h) continue;
    if (!buttonEnabled(b.id, s)) return JsonValue();
    if (b.id == "measure") {
      cmd.set("cmd", s.measureState == "capturing" ? "measure_stop" : "measure_start");
    } else if (b.id == "light") {
      cmd.set("cmd", "light");
      cmd.set("on", !s.lightOn);
    } else {
      cmd.set("cmd", b.id);
    }
    return cmd;
  }
  return JsonValue();
}

void FbUi::onTap(int x, int y, const SystemState& s) {
  const JsonValue cmd = tapCommand(x, y, s);
  if (cmd.isNull()) return;
  const JsonValue reply = app_.command(cmd);
  if (!jBool(reply, "ok", false))
    LOGI("ui", "%s: %s", jStr(cmd, "cmd", "").c_str(), jStr(reply, "error", "").c_str());
}

void FbUi::run() {
  const int tz = app_.config().tzOffsetMin;
  while (running_) {
    const int64_t start = monoMs();
    SystemState s = app_.snapshot();
    MeasurementEngine::Live live = app_.cameraLive();
    render(canvas_, s, live, start, tz);
    display_.present(canvas_);
    // Handle touches until the next frame (~8 fps).
    int64_t left = 125 - (monoMs() - start);
    while (left > 0 && running_) {
      if (touch_.fd() >= 0) {
        pollfd p{touch_.fd(), POLLIN, 0};
        if (poll(&p, 1, static_cast<int>(left)) > 0) {
          int tx, ty;
          if (touch_.readTap(tx, ty)) onTap(tx, ty, app_.snapshot());
        }
      } else {
        sleepMs(static_cast<int>(left));
      }
      left = 125 - (monoMs() - start);
    }
  }
}

}  // namespace vm
