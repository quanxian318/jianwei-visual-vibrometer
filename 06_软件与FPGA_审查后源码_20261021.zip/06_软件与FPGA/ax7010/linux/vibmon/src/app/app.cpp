#include "app/app.h"

#include <sys/epoll.h>
#include <sys/signalfd.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <cmath>
#include <csignal>
#include <cstdlib>

#include "app/report.h"
#include "app/storage.h"
#include "hw/sysfs_find.h"
#include "ui/fb_ui.h"
#include "util/clock.h"
#include "util/log.h"

namespace vm {

namespace {
const char* kTag = "app";

JsonValue okReply(const JsonValue& data = JsonValue()) {
  JsonValue r = JsonValue::makeObject();
  r.set("ok", true);
  if (!data.isNull()) r.set("data", data);
  return r;
}

JsonValue errReply(const std::string& e) {
  JsonValue r = JsonValue::makeObject();
  r.set("ok", false);
  r.set("error", e);
  return r;
}

std::string upperHex(std::string s) {
  for (auto& c : s) c = static_cast<char>(toupper(static_cast<unsigned char>(c)));
  return s;
}

bool dirExists(const std::string& p) {
  struct stat st;
  return stat(p.c_str(), &st) == 0 && S_ISDIR(st.st_mode);
}

const char* measureStateName(MeasurementEngine::State s) {
  switch (s) {
    case MeasurementEngine::State::kStopped: return "stopped";
    case MeasurementEngine::State::kPreview: return "preview";
    case MeasurementEngine::State::kCapturing: return "capturing";
    case MeasurementEngine::State::kAnalyzing: return "analyzing";
  }
  return "stopped";
}
}  // namespace

Application::Application(const AppConfig& cfg) : cfg_(cfg) {}

Application::~Application() {
  ui_.reset();
  ctl_.reset();
  if (engine_) engine_->stopCamera();
  if (sensors_) sensors_->stop();
  printer_.reset();
}

// ---------------------------------------------------------------------------
// Start-up
// ---------------------------------------------------------------------------

void Application::openDevices() {
  std::string dev = cfg_.carrierDev.empty() ? findUioByBase(cfg_.carrierBase) : cfg_.carrierDev;
  if (!dev.empty() && uio_.open(dev, creg::kMapSize)) {
    carrier_.reset(new CarrierCtrl(uio_));
    uint32_t ver = 0;
    carrierOk_ = carrier_->probe(&ver);
    if (carrierOk_) {
      LOGI(kTag, "carrier_ctrl %s v%u.%u, %u Hz", dev.c_str(), ver >> 16, ver & 0xFFFF, carrier_->clockHz());
      tickClock_.setHz(carrier_->clockHz());
    } else {
      LOGE(kTag, "%s does not identify as carrier_ctrl", dev.c_str());
    }
  } else {
    LOGE(kTag, "carrier_ctrl UIO device not found (AXI 0x%08llx)", static_cast<unsigned long long>(cfg_.carrierBase));
  }

  dev = cfg_.i2cMgmtDev.empty() ? findI2cDevByBase(cfg_.i2cMgmtBase) : cfg_.i2cMgmtDev;
  if (dev.empty() || !i2cMgmt_.open(dev)) LOGE(kTag, "management I2C (I2C0) not available");
  dev = cfg_.i2cSensDev.empty() ? findI2cDevByBase(cfg_.i2cSensBase) : cfg_.i2cSensDev;
  if (dev.empty() || !i2cSens_.open(dev)) LOGW(kTag, "sensor I2C (I2C1) not available");

  dev = cfg_.spiImuDev.empty() ? findSpidevByBase(cfg_.spiSensBase, 0) : cfg_.spiImuDev;
  if (cfg_.imu.enabled && (dev.empty() || !spiImu_.open(dev, 0, cfg_.imu.spiHz))) LOGW(kTag, "IMU spidev missing");
  dev = cfg_.spiAdxlDev.empty() ? findSpidevByBase(cfg_.spiSensBase, 1) : cfg_.spiAdxlDev;
  if (cfg_.adxl.enabled && (dev.empty() || !spiAdxl_.open(dev, 3, cfg_.adxl.spiHz))) LOGW(kTag, "ADXL345 spidev missing");

  dev = cfg_.uartNanoDev.empty() ? findTtyByBase(cfg_.uartNanoBase) : cfg_.uartNanoDev;
  if (dev.empty() || !nanoPort_.open(dev, cfg_.nano.baud, cfg_.nano.flowControl)) {
    LOGE(kTag, "Nano UART not available");
  }
}

bool Application::init() {
  // Worker threads inherit this mask; install it before creating any of them.
  sigset_t mask;
  sigemptyset(&mask);
  sigaddset(&mask, SIGINT);
  sigaddset(&mask, SIGTERM);
  if (pthread_sigmask(SIG_BLOCK, &mask, nullptr) != 0) return false;
  state_.update([&](SystemState& s) {
    s.lightPercent[0] = cfg_.light.percent[0];
    s.lightPercent[1] = cfg_.light.percent[1];
    s.roiCx = cfg_.roiCenterX;
    s.roiCy = cfg_.roiCenterY;
  });
  std::string err;
  if (!cfg_.calibrationFile.empty() && loadCalibration(cfg_.calibrationFile, cfg_.measure, err)) {
    LOGI(kTag, "calibration %s: %.6g mm/px (axis %c)", cfg_.measure.calibrationId.c_str(), cfg_.measure.mmPerPx,
         cfg_.measure.axis);
  } else {
    LOGW(kTag, "no valid calibration (%s): results stay in pixels", err.c_str());
  }

  openDevices();
  state_.update([&](SystemState& s) { s.carrierOk = carrierOk_; });

  board_.reset(new BoardService(i2cMgmt_, cfg_, state_));
  if (i2cMgmt_.isOpen()) {
    board_->init();
    board_->allLoadsOff();
    loadRtcTime();
  }
  alarm_.reset(new AlarmService(*board_, cfg_.alarm));

  if (carrierOk_) {
    carrier_->setPwmEnable(false, false);
    carrier_->setPwmFrequency(cfg_.light.pwmHz);
    carrier_->setPwmKills(true, true);
    panel_.reset(new PanelService(*carrier_, cfg_.panel));
    PanelService::Callbacks cb;
    cb.keyShort = [this]() { muteAlarm(); };
    cb.keyLong = [this]() { requestShutdown(); };
    cb.zoomSteps = [this](int steps) {
      state_.update([steps](SystemState& s) {
        s.zoom = std::max(1.0, std::min(8.0, s.zoom * std::pow(1.25, steps)));
      });
    };
    cb.zoomReset = [this]() {
      state_.update([](SystemState& s) {
        s.zoom = 1.0;
        s.zoomCx = s.zoomCy = 0.5;
      });
    };
    panel_->setCallbacks(cb);
    panel_->init();
    setupCarrierEvents();
    const uint32_t in = carrier_->inputs();
    if (((in >> kSrcPfailN) & 1u) == 0) powerFail(true);
  }

  // Nano link.
  NanoLink::Config nc;
  nc.timeoutMs = cfg_.nano.timeoutMs;
  nc.statusPeriodMs = cfg_.nano.statusPeriodMs;
  nc.offlineResetMs = board_->tcaReady() ? cfg_.nano.offlineResetMs : 0;
  nc.axVersion = std::string("vibmon ") + VIBMON_APP_VERSION;
  nanoChan_.reset(new SerialChannel(nanoPort_));
  nano_.reset(new NanoLink(*nanoChan_, nc));
  nano_->setEventHandler([this](const NanoEvent& e) { onNanoEvent(e); });
  nano_->setOnlineHandler([this](bool online, const std::string& boot, bool newBoot) {
    state_.update([online](SystemState& s) { s.nanoOnline = online; });
    if (online) {
      nanoOfflineSinceMs_ = 0;
      LOGI(kTag, "Nano online (boot %s%s)", boot.c_str(), newBoot ? ", new" : "");
      syncTimeFromNano();
    } else if (nanoOfflineSinceMs_ == 0) {
      nanoOfflineSinceMs_ = monoMs();
    }
  });
  nano_->setResetHook([this]() {
    if (shutdown_ || pfail_) return;
    board_->setNanoReset(true);
    loop_.addTimer(cfg_.nano.resetPulseMs, [this]() { board_->setNanoReset(false); }, false);
  });
  if (nanoPort_.isOpen()) {
    loop_.addFd(nanoPort_.fd(), EPOLLIN, [this](uint32_t) { nano_->onReadable(monoMs()); });
    if (carrierOk_) nano_->setIrqLevel(((carrier_->inputs() >> kSrcEspIrq) & 1u) != 0);
  }
  nanoOfflineSinceMs_ = monoMs();

  // Sensors (own thread).
  sensors_.reset(new SensorService(cfg_, state_, tickClock_));
  sensors_->start(i2cSens_.isOpen() ? &i2cSens_ : nullptr, spiImu_.isOpen() ? &spiImu_ : nullptr,
                  spiAdxl_.isOpen() ? &spiAdxl_ : nullptr);

  // Printer (own thread).
  const std::string prnDev = cfg_.uartPrnDev.empty() ? findTtyByBase(cfg_.uartPrnBase) : cfg_.uartPrnDev;
  if (prnDev.empty()) LOGW(kTag, "printer UART not found");
  printer_.reset(new PrinterService(cfg_.printer, *board_, state_, prnDev));
  printer_->setGate([this]() -> std::string {
    // No synchronous call into the event loop: it may already be exiting.
    if (shutdown_) return "shutdown";
    if (pfail_) return "power_fail";
    if (measuring_) return "measuring";
    if (!board_->heavyLoadAllowed()) return "power_budget";
    if (state_.snapshot().lightOn) return "lights_on";
    return std::string();
  });
  printer_->setDoneHandler([this](bool ok, const std::string& id, const std::string& error) {
    loop_.post([this, ok, id, error]() { onPrintDone(ok, id, error); });
  });

  // Camera.
  std::unique_ptr<FrameSource> src;
  if (cfg_.camera.source == "synthetic") {
    src = makeSyntheticSource(cfg_.camera.synthetic);
  } else {
    src = makeV4l2Source(cfg_.camera.v4l2);
  }
  engine_.reset(new MeasurementEngine(std::move(src)));
  if (!engine_->startCamera()) {
    LOGW(kTag, "camera not available; retrying every 5 s");
    cameraRetryMs_ = monoMs() + 5000;
  }

  // Control socket and UI.
  ctl_.reset(new ControlServer(loop_, [this](const JsonValue& c) { return handleCommand(c); }));
  ctl_->listen(cfg_.controlSocket);
  if (cfg_.ui.enabled) {
    ui_.reset(new FbUi(*this));
    if (!ui_->start()) ui_.reset();
  }

  // Signals -> orderly exit.
  int sfd = signalfd(-1, &mask, SFD_NONBLOCK | SFD_CLOEXEC);
  if (sfd >= 0) {
    loop_.addFd(sfd, EPOLLIN, [this, sfd](uint32_t) {
      signalfd_siginfo si;
      while (read(sfd, &si, sizeof(si)) > 0) {
      }
      requestExit();
    });
  }

  loop_.addTimer(20, [this]() {
    pumpCarrierEvents();
    nano_->tick(monoMs());
  });
  loop_.addTimer(100, [this]() { every100ms(); });
  loop_.addTimer(200, [this]() { every200ms(); });
  loop_.addTimer(1000, [this]() { every1s(); });

  state_.update([](SystemState& s) { s.initDone = true; });
  if (panel_) panel_->setSystem(PanelService::Sys::kOk);
  LOGI(kTag, "vibmon %s started", VIBMON_APP_VERSION);
  return true;
}

void Application::setupCarrierEvents() {
  const uint32_t rise = (1u << kSrcImuInt1) | (1u << kSrcAdxlDrdy) | (1u << kSrcRtc1Hz) | (1u << kSrcTach) |
                        (1u << kSrcPfailN) | (1u << kSrcEspIrq) | (1u << kSrcKey) | (1u << kSrcEncSw) |
                        (1u << kSrcKeyLong) | (1u << kSrcEncSwLong) | (1u << kSrcEncStep);
  const uint32_t fall = (1u << kSrcPfailN) | (1u << kSrcExpIntN) | (1u << kSrcEspIrq) | (1u << kSrcKey) |
                        (1u << kSrcEncSw);
  carrier_->enableIrq(false);
  carrier_->clearEvents();
  carrier_->configureEvents(rise, fall);
  carrier_->enableIrq(true);
  uio_.enableIrq();
  loop_.addFd(uio_.fd(), EPOLLIN, [this](uint32_t) {
    uio_.ackIrq();
    pumpCarrierEvents();
    uio_.enableIrq();
  });
}

void Application::pumpCarrierEvents() {
  if (!carrierOk_) return;
  std::vector<CarrierEvent> events;
  for (int round = 0; round < 8; ++round) {
    if (carrier_->popEvents(events, 256) == 0) break;
  }
  for (const auto& e : events) onCarrierEvent(e);
}

void Application::onCarrierEvent(const CarrierEvent& e) {
  switch (e.source) {
    case kSrcImuInt1:
    case kSrcAdxlDrdy:
      sensors_->onDrdy(e);
      break;
    case kSrcEspIrq:
      nano_->setIrqLevel(e.level);
      break;
    case kSrcExpIntN:
      if (!e.level && board_) board_->pollInputs();
      break;
    case kSrcPfailN:
      if (!e.level) {
        powerFail(true);
      } else {
        pfailHighSinceMs_ = monoMs();
      }
      break;
    case kSrcTach: {
      if (lastTachTicks_ != 0 && e.ticks > lastTachTicks_) {
        tachPeriods_.push_back(static_cast<double>(e.ticks - lastTachTicks_) / carrier_->clockHz());
        if (tachPeriods_.size() > 16) tachPeriods_.pop_front();
      }
      lastTachTicks_ = e.ticks;
      lastTachMs_ = monoMs();
      break;
    }
    case kSrcRtc1Hz:
      break;
    default:
      if (panel_) panel_->onEvent(e);
      break;
  }
}

// ---------------------------------------------------------------------------
// Time
// ---------------------------------------------------------------------------

void Application::loadRtcTime() {
  int64_t sec = 0;
  bool valid = false;
  if (!board_->readRtc(sec, valid)) return;
  if (!valid) {
    LOGW(kTag, "DS3231 time invalid (oscillator stopped / never set)");
    return;
  }
  const int64_t delta = sec * 1000 - realtimeMs();
  if (std::llabs(delta) > 2000 && !setRealtimeMs(sec * 1000)) {
    LOGW(kTag, "cannot set the system clock from RTC");
    return;
  }
  state_.update([](SystemState& s) {
    s.timeValid = true;
    s.timeSource = "rtc";
  });
}

void Application::applyTime(int64_t unixMs, const char* source) {
  const int64_t delta = unixMs - realtimeMs();
  const bool valid = state_.snapshot().timeValid;
  if (!valid || std::llabs(delta) > 500) {
    if (!setRealtimeMs(unixMs)) {
      LOGW(kTag, "setting system time failed");
      return;
    }
    LOGI(kTag, "system time set from %s (delta %lld ms)", source, static_cast<long long>(delta));
  }
  // Write the RTC on the next whole second (it has 1 s resolution).
  const int wait = static_cast<int>(1000 - realtimeMs() % 1000);
  loop_.addTimer(wait, [this]() { board_->writeRtc((realtimeMs() + 500) / 1000); }, false);
  const std::string src = source;
  state_.update([src](SystemState& s) {
    s.timeValid = true;
    s.timeSource = src;
  });
  lastTimeSyncMs_ = monoMs();
}

void Application::syncTimeFromNano() {
  if (!nano_->online()) return;
  const int64_t sent = monoMs();
  nano_->request(vp::kOpGetTime, JsonValue::makeObject(), [this, sent](const NanoReply& r) {
    bool valid = false;
    int64_t unixMs = 0;
    if (!r.ok || !r.data.getBool("valid", valid) || !valid || !r.data.getInt("unix_ms", unixMs)) return;
    const int64_t rtt = monoMs() - sent;
    applyTime(unixMs + rtt / 2, "ntp");
  });
}

// ---------------------------------------------------------------------------
// Nano events
// ---------------------------------------------------------------------------

void Application::onNanoEvent(const NanoEvent& e) {
  const int64_t now = monoMs();
  if (e.type == "NFC_TAG") {
    const std::string uid = upperHex(e.data.find("uid") ? e.data.find("uid")->asString() : std::string());
    auto it = cfg_.points.find(uid);
    const std::string id = it != cfg_.points.end() ? it->second.id : "UID-" + uid;
    const std::string name = it != cfg_.points.end() ? it->second.name : std::string();
    state_.update([&](SystemState& s) {
      s.pointUid = uid;
      s.pointId = id;
      s.pointName = name;
    });
    if (panel_) panel_->flash(PanelService::Flash::kNfc, now);
    setMessage("测点: " + id + (name.empty() ? "" : " " + name));
  } else if (e.type == "WIFI_STATE" || e.type == "SD_STATE") {
    updateFromNanoStatus();
  } else if (e.type == "TIME_SYNC") {
    syncTimeFromNano();
  } else if (e.type == "AUDIO_FAILED") {
    LOGW(kTag, "voice failed: %s", vp::jsonSerialize(e.data).c_str());
  } else if (e.type == "FAULT") {
    LOGW(kTag, "Nano fault: %s", vp::jsonSerialize(e.data).c_str());
  } else if (e.type == "BOOT") {
    LOGI(kTag, "Nano booted: %s", vp::jsonSerialize(e.data).c_str());
  }
}

void Application::updateFromNanoStatus() {
  const JsonValue& st = nano_->lastStatus();
  const JsonValue& wifi = jObj(st, "wifi");
  const std::string ws = jStr(wifi, "state", "UNKNOWN");
  state_.update([&](SystemState& s) {
    s.wifiState = nano_->online() ? ws : "UNKNOWN";
    s.wifiSsid = jStr(wifi, "ssid", "");
    s.wifiIp = jStr(wifi, "ip", "");
    s.sdMounted = jBool(jObj(st, "sd"), "mounted", false);
    s.nfcReady = jBool(jObj(st, "nfc"), "ready", false);
  });
  if (panel_) {
    PanelService::Net n = PanelService::Net::kFailed;
    if (!nano_->online()) {
      n = PanelService::Net::kFailed;
    } else if (ws == "OFF") {
      n = PanelService::Net::kOff;
    } else if (ws == "CONNECTING") {
      n = PanelService::Net::kConnecting;
    } else if (ws == "CONNECTED") {
      n = PanelService::Net::kConnected;
    }
    panel_->setNetwork(n);
  }
}

void Application::muteAlarm() {
  alarm_->mute();
  if (!lastVoiceJob_.empty() && nano_ && nano_->online()) {
    JsonValue p = JsonValue::makeObject();
    p.set("job_id", lastVoiceJob_);
    nano_->request(vp::kOpStopVoice, p, nullptr);
  }
  state_.update([](SystemState& s) { s.alarmMuted = true; });
  setMessage("报警已确认, 声音已静音");
}

void Application::playVoice(const char* asset) {
  if (!cfg_.voice.enabled || !nano_->online() || pfail_ || shutdown_) return;
  lastVoiceJob_ = nano_->playVoice(asset, cfg_.voice.volume, [asset](const NanoReply& r) {
    if (!r.ok) LOGW("voice", "PLAY_VOICE %s refused: %s", asset, r.code.c_str());
  });
}

// ---------------------------------------------------------------------------
// Measurement, printing, light
// ---------------------------------------------------------------------------

bool Application::setLight(bool on, std::string* err) {
  if (!carrierOk_) {
    if (err) *err = "no_carrier";
    return false;
  }
  if (on && (pfail_ || shutdown_)) {
    if (err) *err = "power_fail";
    on = false;
  } else if (on && !board_->heavyLoadAllowed()) {
    if (err) *err = "power_budget";
    on = false;
  } else if (on && printer_->busy()) {
    if (err) *err = "printing";
    on = false;
  }
  const SystemState s = state_.snapshot();
  carrier_->setPwmPercent(0, s.lightPercent[0]);
  carrier_->setPwmPercent(1, s.lightPercent[1]);
  carrier_->setPwmEnable(on, on);
  lightWanted_ = on;
  state_.update([on](SystemState& st) { st.lightOn = on; });
  return on;
}

std::string Application::makeMeasurementId() {
  std::string base = cfg_.deviceId + "-";
  if (state_.snapshot().timeValid) {
    base += formatLocal(realtimeMs(), cfg_.tzOffsetMin, "%Y%m%d-%H%M%S");
  } else {
    base += "M" + std::to_string(monoMs());
  }
  std::string id = base;
  for (int n = 2; dirExists(cfg_.recordsDir + "/" + id); ++n) id = base + "-" + std::to_string(n);
  return id;
}

bool Application::startMeasurement(double durationS, std::string& err) {
  if (shutdown_ || pfail_) {
    err = "power";
    return false;
  }
  if (measuring_) {
    err = "already_measuring";
    return false;
  }
  if (printer_->busy()) {
    err = "printing";
    return false;
  }
  if (!engine_ || engine_->state() != MeasurementEngine::State::kPreview) {
    err = "camera_not_ready";
    return false;
  }
  MeasureConfig mc = cfg_.measure;
  if (durationS > 0) mc.durationS = durationS;
  const SystemState s = state_.snapshot();
  lightAuto_ = false;
  if (cfg_.light.autoOnMeasure && !s.lightOn) {
    std::string lerr;
    lightAuto_ = setLight(true, &lerr);
    if (!lightAuto_) LOGW(kTag, "light not switched on: %s", lerr.c_str());
  }
  captureContext_ = state_.snapshot();  // Freeze point, illumination and UTC mapping for this record.
  captureStartMonoNs_ = monoNs();
  captureStartUtcMs_ = realtimeMs();
  const uint64_t generation = ++captureGeneration_;
  if (!engine_->beginCapture(mc, s.roiCx, s.roiCy,
      [this, generation](const MeasureResult& r) {
        loop_.post([this, generation, r]() {
          if (!shutdown_ && !pfail_ && generation == captureGeneration_ && measuring_) onMeasureDone(r);
        });
      })) {
    err = "capture_refused";
    if (lightAuto_) setLight(false, nullptr);
    return false;
  }
  measuring_ = true;
  if (cfg_.fan.pauseDuringMeasure && fanOn_) {
    board_->setFan(false);
    fanOn_ = false;
  }
  setMessage("测量中...");
  return true;
}

void Application::stopMeasurement() {
  if (measuring_ && engine_) engine_->endCapture();
}

void Application::onMeasureDone(const MeasureResult& r) {
  measuring_ = false;
  const int64_t now = monoMs();
  if (lightAuto_) setLight(false, nullptr);
  lightAuto_ = false;
  const SystemState s = state_.snapshot();
  const bool cal = r.mmPerPx > 0;
  const double k = cal ? r.mmPerPx : 1.0;

  ResultSummary sum;
  sum.have = true;
  sum.valid = r.valid;
  sum.reason = r.reason;
  sum.unit = cal ? "mm" : "px";
  sum.dominantHz = r.dominantHz;
  sum.peakToPeak = r.ppPx * k;
  sum.rms = r.rmsPx * k;
  sum.peak = r.peakAmpPx * k;
  sum.fps = r.fpsMeasured;
  sum.dropped = r.dropped;
  sum.pointId = captureContext_.pointId;
  sum.utcMs = realtimeMs();
  sum.level = r.valid && cal ? AlarmService::classify(sum.peakToPeak, cfg_.alarm.warnPp, cfg_.alarm.alarmPp)
                             : AlarmLevel::kUnknown;
  sum.measurementId = makeMeasurementId();

  if (r.valid && cal) {
    alarm_->setLevel(sum.level, now);
    if (panel_) panel_->setAlarm(sum.level);
  }

  // Save first: the printed slip is generated from the saved record.
  if (pfail_) {
    setMessage("掉电预警: 本次结果未保存");
  } else if (r.frames > 0) {
    RecordMeta m;
    m.measurementId = sum.measurementId;
    m.deviceId = cfg_.deviceId;
    m.pointId = captureContext_.pointId;
    m.pointName = captureContext_.pointName;
    m.nfcUid = captureContext_.pointUid;
    m.startUtcMs = captureStartUtcMs_ + (r.startMonoNs - captureStartMonoNs_) / 1000000;
    m.timeValid = captureContext_.timeValid;
    m.timeSource = captureContext_.timeSource;
    m.tzOffsetMin = cfg_.tzOffsetMin;
    m.cameraSource = engine_->live().source;
    m.lightOn = captureContext_.lightOn;
    m.lightPercent[0] = captureContext_.lightPercent[0];
    m.lightPercent[1] = captureContext_.lightPercent[1];
    m.unit = sum.unit;
    m.level = sum.level;
    m.warnPp = cfg_.alarm.warnPp;
    m.alarmPp = cfg_.alarm.alarmPp;
    m.envValid = s.envValid;
    m.tempC = s.tempC;
    m.rhPercent = s.rhPercent;
    m.distanceValid = s.distanceValid;
    m.distanceMm = s.distanceMm;
    m.appVersion = VIBMON_APP_VERSION;
    m.plVersion = carrierOk_ ? "carrier_ctrl 1.0" : "";
    m.nanoVersion = jStr(nano_->helloData(), "nano_version", "");
    std::vector<ImuSample> imu;
    std::vector<AdxlSample> adxl;
    const int64_t t1 = r.startMonoNs + static_cast<int64_t>(r.durationS * 1e9);
    sensors_->imuWindow(r.startMonoNs, t1, imu);
    sensors_->adxlWindow(r.startMonoNs, t1, adxl);
    std::string err;
    sum.saved = saveRecord(cfg_.recordsDir, m, r, imu, adxl, err);
    if (sum.saved) {
      lastRecordId_ = sum.measurementId;
    } else {
      LOGE(kTag, "saving %s failed: %s", sum.measurementId.c_str(), err.c_str());
      if (panel_) panel_->flash(PanelService::Flash::kFailure, now);
      playVoice("storage_error");
    }
  }

  if (r.valid) {
    char buf[128];
    snprintf(buf, sizeof(buf), "主频 %.2f Hz, 峰峰值 %.4g %s, %s", sum.dominantHz, sum.peakToPeak, sum.unit.c_str(),
             levelText(sum.level));
    setMessage(buf);
    if (sum.saved || pfail_) {
      playVoice(sum.level == AlarmLevel::kAlarm ? "vibration_alarm"
                                                : (sum.level == AlarmLevel::kWarn ? "vibration_warn" : "measure_done"));
    }
    if (panel_ && sum.saved) panel_->flash(PanelService::Flash::kSuccess, now);
  } else {
    setMessage("测量无效: " + r.reason);
  }
  state_.update([&](SystemState& st) {
    st.last = sum;
    st.alarmLevel = alarm_->level();
    st.alarmMuted = alarm_->muted();
  });
}

bool Application::printRecord(const std::string& idIn, std::string& err) {
  const std::string id = idIn.empty() ? (lastRecordId_.empty() ? latestRecordId(cfg_.recordsDir) : lastRecordId_) : idIn;
  if (id.empty()) {
    err = "no_record";
    return false;
  }
  if (pfail_ || shutdown_) {
    err = "power";
    return false;
  }
  if (measuring_) {
    err = "measuring";
    return false;
  }
  if (!board_->heavyLoadAllowed()) {
    err = "power_budget";
    return false;
  }
  if (state_.snapshot().lightOn) setLight(false, nullptr);
  JsonValue rec;
  ReportData d;
  if (!loadRecord(cfg_.recordsDir, id, rec, d.t, d.disp, d.f, d.amp)) {
    err = "record_unreadable";
    return false;
  }
  const JsonValue& res = jObj(rec, "result");
  d.deviceId = jStr(rec, "device_id", cfg_.deviceId);
  d.measurementId = id;
  const std::string local = jStr(rec, "start_local", "");
  if (local.empty()) {
    d.timeText = "时间未校准";
  } else {
    const int tz = static_cast<int>(jInt(rec, "timezone_offset_min", cfg_.tzOffsetMin));
    char tzs[24];
    snprintf(tzs, sizeof(tzs), " (UTC%+d)", tz / 60);
    d.timeText = local + tzs;
  }
  d.pointText = jStr(rec, "point_id", "") + " " + jStr(rec, "point_name", "");
  d.summary.valid = jBool(res, "valid", false);
  d.summary.reason = jStr(res, "reason", "");
  d.summary.unit = jStr(res, "unit", "px");
  const bool mm = d.summary.unit == "mm";
  d.summary.dominantHz = jNum(res, "dominant_frequency_hz", 0);
  d.summary.peakToPeak = jNum(res, mm ? "displacement_peak_to_peak_mm" : "displacement_peak_to_peak_px", 0);
  d.summary.rms = jNum(res, mm ? "displacement_rms_mm" : "displacement_rms_px", 0);
  d.summary.peak = jNum(res, mm ? "spectral_peak_mm" : "spectral_peak_px", 0);
  const std::string lv = jStr(res, "level", "normal");
  d.summary.level = lv == "alarm" ? AlarmLevel::kAlarm :
                    (lv == "warn" ? AlarmLevel::kWarn : (lv == "normal" ? AlarmLevel::kNormal : AlarmLevel::kUnknown));
  const JsonValue& cam = jObj(rec, "camera");
  d.fps = jNum(cam, "fps_measured", 0);
  d.dropped = static_cast<uint32_t>(jInt(cam, "frames_dropped", 0));
  const JsonValue& cal = jObj(rec, "calibration");
  d.calibrationText = mm ? jStr(cal, "id", "已标定") : std::string("未标定 (像素)");
  const JsonValue& env = jObj(rec, "environment");
  if (jBool(env, "valid", false)) {
    char buf[64];
    snprintf(buf, sizeof(buf), "环境 %.1f °C  %.0f %%RH", jNum(env, "temperature_c", 0), jNum(env, "humidity_percent", 0));
    d.envText = buf;
  }
  // Keep the spectrum plot to the analysed band.
  while (!d.f.empty() && d.f.back() > d.fps * 0.4 && d.fps > 0) {
    d.f.pop_back();
    d.amp.pop_back();
  }
  // The 384-dot slip shows about ten periods of the waveform, not all samples.
  const double window = d.summary.valid && d.summary.dominantHz > 0 ? 10.0 / d.summary.dominantHz : 2.0;
  if (!d.t.empty() && d.t.back() - d.t.front() > window) {
    const double t0 = d.t.front();
    size_t n = 0;
    while (n < d.t.size() && d.t[n] - t0 <= window) ++n;
    d.t.resize(n);
    d.disp.resize(n);
  }
  Canvas c = renderReport(d, cfg_.printer.widthDots);
  PrintJob job;
  job.id = id;
  job.bits = toMonoBits(c, job.widthBytes);
  job.height = c.height();
  if (!printer_->submit(std::move(job), err)) return false;
  if (panel_) panel_->setPrinting(true);
  state_.update([](SystemState& s) { s.printerState = "starting"; });
  setMessage("打印中...");
  return true;
}

void Application::onPrintDone(bool ok, const std::string& id, const std::string& error) {
  if (panel_) {
    panel_->setPrinting(false);
    panel_->flash(ok ? PanelService::Flash::kSuccess : PanelService::Flash::kFailure, monoMs());
  }
  if (ok) {
    setMessage("打印完成: " + id);
  } else {
    setMessage("打印失败: " + error);
    playVoice("print_failed");
  }
}

// ---------------------------------------------------------------------------
// Power fail and shutdown
// ---------------------------------------------------------------------------

void Application::powerFail(bool active) {
  if (active == pfail_) return;
  pfail_ = active;
  state_.update([active](SystemState& s) { s.pfail = active; });
  if (active) {
    LOGW(kTag, "PFAIL: 12 V below threshold - loads off, no new prints or writes");
    setLight(false, nullptr);  // the PL already forced the PWM low
    board_->inhibitPrinter(true);
    if (printer_) printer_->abort("power_fail");
    ++captureGeneration_;
    if (measuring_) engine_->cancel();
    measuring_ = false;
    alarm_->suspend(true);
    board_->allLoadsOff();
    fanOn_ = false;
    setMessage("电源掉电预警");
  } else {
    LOGI(kTag, "PFAIL released");
    carrier_->clearPwmKills();
    if (!shutdown_) board_->inhibitPrinter(false);
    if (!shutdown_) alarm_->suspend(false);
    setMessage("电源恢复");
  }
}

void Application::requestShutdown() {
  if (shutdown_) return;
  shutdown_ = true;
  ++captureGeneration_;
  LOGI(kTag, "shutdown requested");
  setMessage("正在准备关机...");
  if (measuring_) engine_->cancel();
  measuring_ = false;
  board_->inhibitPrinter(true);
  printer_->abort("shutdown");
  setLight(false, nullptr);
  alarm_->suspend(true);
  board_->allLoadsOff();
  fanOn_ = false;
  // Finish after the Nano confirmed PREPARE_POWER_OFF, or after 1.5 s at most.
  auto done = std::make_shared<bool>(false);
  auto finish = [this, done]() {
    if (*done) return;
    *done = true;
    finishShutdown();
  };
  if (nano_->online()) {
    JsonValue p = JsonValue::makeObject();
    p.set("reason", "operator_shutdown");
    nano_->request(vp::kOpPreparePowerOff, p, [finish](const NanoReply&) { finish(); });
  }
  loop_.addTimer(1500, finish, false);
}

void Application::finishShutdown() {
  if (printer_ && printer_->busy()) {
    loop_.addTimer(50, [this]() { finishShutdown(); }, false);
    return;
  }
  if (engine_) engine_->stopCamera();
  sync();
  if (panel_) {
    panel_->prepareShutdown();
    panel_->tick(monoMs());
  }
  state_.update([](SystemState& s) { s.shutdownPrepared = true; });
  setMessage(cfg_.poweroffOnShutdown ? "应用已停止, 等待Linux关机" : "应用已停止, Linux仍在运行");
  LOGI(kTag, "application prepared; OS shutdown %s", cfg_.poweroffOnShutdown ? "pending" : "disabled");
  if (cfg_.poweroffOnShutdown) {
    loop_.addTimer(1500, [this]() {
      if (std::system("/sbin/poweroff") != 0) LOGW(kTag, "poweroff command failed");
      requestExit();
    }, false);
  }
}

void Application::requestExit() {
  loop_.post([this]() {
    if (exiting_) return;
    exiting_ = true;
    shutdown_ = true;
    ++captureGeneration_;
    measuring_ = false;
    if (engine_) engine_->cancel();
    if (board_) board_->inhibitPrinter(true);
    if (printer_) printer_->abort("exit");
    if (carrierOk_) {
      carrier_->setPwmEnable(false, false);
      {
        carrier_->setWatchdog(0);  // orderly exit: no fault frame
        const uint32_t off[5] = {0, 0, 0, 0, 0};
        carrier_->setLeds(off);
        carrier_->sendLeds();
      }
    }
    if (board_ && board_->tcaReady()) board_->allLoadsOff();
    loop_.stop();
  });
}

void Application::setMessage(const std::string& msg) {
  LOGI(kTag, "%s", msg.c_str());
  const int64_t now = monoMs();
  state_.update([&](SystemState& s) {
    s.message = msg;
    s.messageMs = now;
  });
}

// ---------------------------------------------------------------------------
// Periodic work
// ---------------------------------------------------------------------------

void Application::every100ms() {
  const int64_t now = monoMs();
  if (engine_) {
    MeasurementEngine::Live l = engine_->live();
    state_.update([&](SystemState& s) {
      s.measureState = measureStateName(l.state);
      s.measureElapsedS = l.elapsedS;
      s.measureDurationS = l.durationS;
      s.cameraOk = l.cameraOk;
    });
    if (panel_) {
      const SystemState s = state_.snapshot();
      PanelService::Meas m = PanelService::Meas::kIdle;
      if (l.state == MeasurementEngine::State::kCapturing) {
        m = (s.lightOn && !s.lightAllowed) ? PanelService::Meas::kConditionBad : PanelService::Meas::kCapturing;
      } else if (l.state == MeasurementEngine::State::kAnalyzing) {
        m = PanelService::Meas::kComputing;
      } else if (!l.cameraOk) {
        m = PanelService::Meas::kConditionBad;
      }
      panel_->setMeasure(m);
    }
  }
  if (alarm_) alarm_->tick(now);
  if (panel_) {
    const SystemState s = state_.snapshot();
    const bool fault = !s.tcaOk || s.pfail || !s.fault.empty();
    if (!shutdown_) panel_->setSystem(fault ? PanelService::Sys::kFault : PanelService::Sys::kOk);
    panel_->tick(now);
  }
}

void Application::every200ms() {
  if (board_ && i2cMgmt_.isOpen()) board_->samplePower();
  if (carrierOk_) {
    tickClock_.addPair(carrier_->timestamp(), monoNs());
    // PFAIL release needs the input high for a full second.
    if (pfail_ && ((carrier_->inputs() >> kSrcPfailN) & 1u) != 0) {
      if (pfailHighSinceMs_ == 0) pfailHighSinceMs_ = monoMs();
      if (monoMs() - pfailHighSinceMs_ >= 1000) powerFail(false);
    } else if (pfail_) {
      pfailHighSinceMs_ = 0;
    }
  }
}

void Application::every1s() {
  const int64_t now = monoMs();
  updateFromNanoStatus();
  if (nano_->online() && now - lastTimeSyncMs_ > 600000 && jBool(nano_->lastStatus(), "time_valid", false)) {
    lastTimeSyncMs_ = now;
    syncTimeFromNano();
  }
  if (board_ && board_->tcaReady() && !pfail_ && !shutdown_) {
    // Fan policy; a paused fan avoids airflow on the target while measuring.
    const SystemState s = state_.snapshot();
    bool want = fanOn_;
    if (cfg_.fan.mode == "on") {
      want = true;
    } else if (cfg_.fan.mode == "off") {
      want = false;
    } else if (s.envValid) {
      if (s.tempC >= cfg_.fan.onTempC) want = true;
      if (s.tempC <= cfg_.fan.offTempC) want = false;
    }
    if (measuring_ && cfg_.fan.pauseDuringMeasure) want = false;
    if (want != fanOn_ && board_->setFan(want)) fanOn_ = want;
  }
  // Tachometer: no pulse for 2 s means no valid speed (never keep the last value).
  double hz = 0;
  bool valid = false;
  if (!tachPeriods_.empty() && now - lastTachMs_ < 2000) {
    double sum = 0;
    for (double p : tachPeriods_) sum += p;
    hz = tachPeriods_.size() / sum;
    valid = true;
  } else {
    tachPeriods_.clear();
    lastTachTicks_ = 0;
  }
  state_.update([&](SystemState& s) {
    s.tachHz = hz;
    s.tachValid = valid;
    if (now - s.messageMs > 15000) s.message.clear();
  });
  if (engine_ && engine_->state() == MeasurementEngine::State::kStopped && !shutdown_ && now >= cameraRetryMs_) {
    cameraRetryMs_ = now + 5000;
    if (engine_->startCamera()) LOGI(kTag, "camera started");
  }
}

MeasurementEngine::Live Application::cameraLive() {
  return engine_ ? engine_->live() : MeasurementEngine::Live();
}

// ---------------------------------------------------------------------------
// Commands (UI and control socket)
// ---------------------------------------------------------------------------

JsonValue Application::command(const JsonValue& cmd) {
  return loop_.call<JsonValue>([this, cmd]() { return handleCommand(cmd); });
}

JsonValue Application::stateJson() {
  const SystemState s = state_.snapshot();
  JsonValue o = JsonValue::makeObject();
  o.set("init_done", s.initDone);
  o.set("carrier_ok", s.carrierOk);
  o.set("tca_ok", s.tcaOk);
  o.set("ina_ok", s.inaOk);
  o.set("rtc_ok", s.rtcOk);
  JsonValue p = JsonValue::makeObject();
  p.set("bus_v", s.power.busV);
  p.set("current_a", s.power.currentA);
  p.set("power_w", s.power.powerW);
  p.set("warn", s.powerWarn);
  p.set("deny_heavy_loads", s.powerDeny);
  p.set("over_current_latched", s.overCurrentLatched);
  p.set("pfail", s.pfail);
  o.set("power", p);
  JsonValue l = JsonValue::makeObject();
  l.set("allowed_by_sw301", s.lightAllowed);
  l.set("on", s.lightOn);
  JsonValue pct = JsonValue::makeArray();
  pct.push(s.lightPercent[0]);
  pct.push(s.lightPercent[1]);
  l.set("percent", pct);
  o.set("light", l);
  JsonValue t = JsonValue::makeObject();
  t.set("valid", s.timeValid);
  t.set("source", s.timeSource);
  t.set("utc", formatUtcIso(realtimeMs()));
  o.set("time", t);
  JsonValue n = JsonValue::makeObject();
  n.set("online", s.nanoOnline);
  n.set("wifi", s.wifiState);
  n.set("ssid", s.wifiSsid);
  n.set("ip", s.wifiIp);
  n.set("sd_mounted", s.sdMounted);
  n.set("nfc_ready", s.nfcReady);
  const NanoLink::Stats& ns = nano_->stats();
  n.set("requests", static_cast<unsigned long>(ns.requests));
  n.set("retries", static_cast<unsigned long>(ns.retries));
  n.set("timeouts", static_cast<unsigned long>(ns.timeouts));
  n.set("events", static_cast<unsigned long>(ns.events));
  n.set("event_gaps", static_cast<unsigned long>(ns.gaps));
  n.set("crc_errors", static_cast<unsigned long>(nano_->decoderStats().crcErrors));
  o.set("nano", n);
  JsonValue pt = JsonValue::makeObject();
  pt.set("uid", s.pointUid);
  pt.set("id", s.pointId);
  pt.set("name", s.pointName);
  o.set("point", pt);
  JsonValue sen = JsonValue::makeObject();
  sen.set("imu_ok", s.imuOk);
  sen.set("adxl345_ok", s.adxlOk);
  sen.set("tof", s.tofNote);
  sen.set("distance_mm", s.distanceValid ? JsonValue(s.distanceMm) : JsonValue());
  sen.set("temperature_c", s.envValid ? JsonValue(s.tempC) : JsonValue());
  sen.set("humidity_percent", s.envValid ? JsonValue(s.rhPercent) : JsonValue());
  sen.set("tach_hz", s.tachValid ? JsonValue(s.tachHz) : JsonValue());
  o.set("sensors", sen);
  JsonValue m = JsonValue::makeObject();
  m.set("state", s.measureState);
  m.set("elapsed_s", s.measureElapsedS);
  m.set("camera_ok", s.cameraOk);
  m.set("roi_center_x", s.roiCx);
  m.set("roi_center_y", s.roiCy);
  if (s.last.have) {
    JsonValue r = JsonValue::makeObject();
    r.set("measurement_id", s.last.measurementId);
    r.set("valid", s.last.valid);
    r.set("reason", s.last.reason);
    r.set("unit", s.last.unit);
    r.set("dominant_hz", s.last.dominantHz);
    r.set("peak_to_peak", s.last.peakToPeak);
    r.set("rms", s.last.rms);
    r.set("level", levelText(s.last.level));
    r.set("saved", s.last.saved);
    m.set("last", r);
  }
  o.set("measurement", m);
  o.set("alarm_level", levelText(s.alarmLevel));
  o.set("alarm_muted", s.alarmMuted);
  o.set("printer", s.printerState);
  o.set("printer_error", s.printerError);
  o.set("message", s.message);
  o.set("shutdown_prepared", s.shutdownPrepared);
  return o;
}

JsonValue Application::handleCommand(const JsonValue& c) {
  const std::string cmd = jStr(c, "cmd", "");
  if (shutdown_ && cmd != "status" && cmd != "shutdown") return errReply("shutting_down");
  std::string err;
  if (cmd == "status") return okReply(stateJson());
  if (cmd == "measure_start") {
    if (!startMeasurement(jNum(c, "duration_s", 0), err)) return errReply(err);
    return okReply();
  }
  if (cmd == "measure_stop") {
    stopMeasurement();
    return okReply();
  }
  if (cmd == "print") {
    if (!printRecord(jStr(c, "measurement_id", ""), err)) return errReply(err);
    return okReply();
  }
  if (cmd == "light") {
    const JsonValue* pct = c.find("percent");
    if (pct && pct->isArray() && pct->size() == 2) {
      const double a = std::max(0.0, std::min(100.0, pct->at(0).asDouble(100)));
      const double b = std::max(0.0, std::min(100.0, pct->at(1).asDouble(100)));
      state_.update([a, b](SystemState& s) {
        s.lightPercent[0] = a;
        s.lightPercent[1] = b;
      });
    }
    const bool on = jBool(c, "on", state_.snapshot().lightOn);
    const bool now = setLight(on, &err);
    if (on && !now) return errReply(err);
    return okReply();
  }
  if (cmd == "mute") {
    muteAlarm();
    return okReply();
  }
  if (cmd == "roi") {
    const double x = std::max(0.05, std::min(0.95, jNum(c, "x", 0.5)));
    const double y = std::max(0.05, std::min(0.95, jNum(c, "y", 0.5)));
    state_.update([x, y](SystemState& s) {
      s.roiCx = x;
      s.roiCy = y;
    });
    return okReply();
  }
  if (cmd == "zoom") {
    const int steps = static_cast<int>(jInt(c, "steps", 0));
    state_.update([steps](SystemState& s) { s.zoom = std::max(1.0, std::min(8.0, s.zoom * std::pow(1.25, steps))); });
    return okReply();
  }
  if (cmd == "zoom_reset") {
    state_.update([](SystemState& s) {
      s.zoom = 1;
      s.zoomCx = s.zoomCy = 0.5;
    });
    return okReply();
  }
  if (cmd == "voice") {
    const std::string asset = jStr(c, "asset", "measure_done");
    if (!nano_->online()) return errReply("nano_offline");
    lastVoiceJob_ = nano_->playVoice(asset, static_cast<int>(jInt(c, "volume", cfg_.voice.volume)), nullptr);
    return okReply();
  }
  if (cmd == "set_net") {
    if (!nano_->online()) return errReply("nano_offline");
    JsonValue p = JsonValue::makeObject();
    p.set("ssid", jStr(c, "ssid", ""));
    p.set("password", jStr(c, "password", ""));
    p.set("persist", jBool(c, "persist", true));
    nano_->request(vp::kOpSetNet, p, [](const NanoReply& r) {
      LOGI("app", "SET_NET: %s", r.ok ? "accepted" : r.code.c_str());
    });
    return okReply();
  }
  if (cmd == "nano_status") return okReply(nano_->lastStatus());
  if (cmd == "rtc_set") {
    int64_t ms = 0;
    if (!c.getInt("unix_ms", ms) || ms < 1700000000000LL) return errReply("bad unix_ms");
    applyTime(ms, "manual");
    return okReply();
  }
  if (cmd == "set_point") {
    const std::string id = jStr(c, "id", "");
    const std::string name = jStr(c, "name", "");
    state_.update([&](SystemState& s) {
      s.pointId = id;
      s.pointName = name;
      s.pointUid.clear();
    });
    return okReply();
  }
  if (cmd == "shutdown") {
    requestShutdown();
    return okReply();
  }
  return errReply("unknown command");
}

int Application::run() {
  loop_.run();
  if (sensors_) sensors_->stop();
  if (engine_) engine_->stopCamera();
  return exitCode_;
}

}  // namespace vm
