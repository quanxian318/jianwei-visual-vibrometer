#pragma once

#include <cstdint>
#include <functional>
#include <mutex>
#include <string>

#include "drv/ina226.h"

namespace vm {

enum class AlarmLevel { kUnknown = -1, kNormal = 0, kWarn = 1, kAlarm = 2 };

struct ResultSummary {
  bool have = false;
  bool valid = false;
  std::string measurementId;
  std::string reason;
  std::string unit = "px";  // mm when calibrated
  double dominantHz = 0, peakToPeak = 0, rms = 0, peak = 0;
  double fps = 0;
  uint32_t dropped = 0;
  AlarmLevel level = AlarmLevel::kUnknown;
  bool saved = false;
  std::string pointId;
  int64_t utcMs = 0;
};

// Everything the UI, LEDs and control socket show. Written by services,
// read as a snapshot copy.
struct SystemState {
  bool initDone = false;
  bool carrierOk = false, tcaOk = false, inaOk = false, rtcOk = false;
  std::string fault;  // non-empty = system fault (HL101 red)

  PowerSample power;
  bool powerWarn = false, powerDeny = false, overCurrentLatched = false;
  bool pfail = false;

  bool lightAllowed = false;  // LIGHT_OK (SW301 closed)
  bool lightOn = false;
  double lightPercent[2] = {100, 100};

  bool timeValid = false;
  std::string timeSource = "none";

  bool nanoOnline = false;
  std::string wifiState = "UNKNOWN", wifiSsid, wifiIp;
  bool sdMounted = false, nfcReady = false;

  std::string pointUid, pointId, pointName;

  bool imuOk = false, adxlOk = false, tofOk = false, shtOk = false;
  std::string tofNote;
  double tempC = 0, rhPercent = 0;
  bool envValid = false;
  int distanceMm = 0;
  bool distanceValid = false;
  double tachHz = 0;  // J705 pulse frequency (pulses per second, before PPR)
  bool tachValid = false;

  std::string printerState = "idle";
  std::string printerError;

  std::string measureState = "stopped";  // stopped | preview | capturing | analyzing
  double measureElapsedS = 0, measureDurationS = 0;
  bool cameraOk = false;
  ResultSummary last;

  AlarmLevel alarmLevel = AlarmLevel::kUnknown;
  bool alarmMuted = false;

  double zoom = 1.0;
  double zoomCx = 0.5, zoomCy = 0.5;
  double roiCx = 0.5, roiCy = 0.5;

  std::string message;  // latest user-facing message
  int64_t messageMs = 0;
  bool shutdownPrepared = false;
};

class StateStore {
 public:
  SystemState snapshot() {
    std::lock_guard<std::mutex> lock(mutex_);
    return s_;
  }
  void update(const std::function<void(SystemState&)>& fn) {
    std::lock_guard<std::mutex> lock(mutex_);
    fn(s_);
  }

 private:
  std::mutex mutex_;
  SystemState s_;
};

}  // namespace vm
