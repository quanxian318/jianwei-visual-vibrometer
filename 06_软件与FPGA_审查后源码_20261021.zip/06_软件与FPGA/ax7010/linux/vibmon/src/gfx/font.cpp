#include "gfx/font.h"

#include <cstdlib>

namespace vm {

#include "gfx/font_data.inc"

namespace {
const FontGlyph* findGlyph(const FontFace& f, uint32_t cp) {
  int lo = 0, hi = f.count - 1;
  while (lo <= hi) {
    const int mid = (lo + hi) / 2;
    if (f.glyphs[mid].codepoint == cp) return &f.glyphs[mid];
    if (f.glyphs[mid].codepoint < cp) {
      lo = mid + 1;
    } else {
      hi = mid - 1;
    }
  }
  return nullptr;
}
}  // namespace

const FontFace& fontFace(int pixelSize) {
  const FontFace* best = kFaces[0];
  for (const FontFace* f : kFaces) {
    if (std::abs(f->pixelSize - pixelSize) < std::abs(best->pixelSize - pixelSize)) best = f;
  }
  return *best;
}

uint32_t nextCodepoint(const std::string& s, size_t& i) {
  const unsigned char c = static_cast<unsigned char>(s[i]);
  uint32_t cp = c;
  int extra = 0;
  if (c >= 0xF0) {
    cp = c & 0x07;
    extra = 3;
  } else if (c >= 0xE0) {
    cp = c & 0x0F;
    extra = 2;
  } else if (c >= 0xC0) {
    cp = c & 0x1F;
    extra = 1;
  }
  ++i;
  for (int k = 0; k < extra && i < s.size(); ++k, ++i) cp = (cp << 6) | (static_cast<unsigned char>(s[i]) & 0x3F);
  return cp;
}

int textWidth(const FontFace& f, const std::string& utf8) {
  int w = 0;
  for (size_t i = 0; i < utf8.size();) {
    const FontGlyph* g = findGlyph(f, nextCodepoint(utf8, i));
    if (!g) g = findGlyph(f, '?');
    if (g) w += g->advance;
  }
  return w;
}

int drawText(Canvas& c, const FontFace& f, int x, int y, const std::string& utf8, uint32_t color) {
  for (size_t i = 0; i < utf8.size();) {
    const FontGlyph* g = findGlyph(f, nextCodepoint(utf8, i));
    if (!g) g = findGlyph(f, '?');
    if (!g) continue;
    const uint8_t* bm = f.bitmap + g->offset;
    for (int gy = 0; gy < g->h; ++gy) {
      for (int gx = 0; gx < g->w; ++gx) {
        const int idx = gy * g->w + gx;
        const uint8_t b = bm[idx >> 1];
        const int a4 = (idx & 1) ? (b & 0x0F) : (b >> 4);
        if (a4) c.blend(x + g->xoff + gx, y + g->yoff + gy, color, a4 * 17);
      }
    }
    x += g->advance;
  }
  return x;
}

int drawTextCentered(Canvas& c, const FontFace& f, int cx, int y, const std::string& utf8, uint32_t color) {
  return drawText(c, f, cx - textWidth(f, utf8) / 2, y, utf8, color);
}

}  // namespace vm
