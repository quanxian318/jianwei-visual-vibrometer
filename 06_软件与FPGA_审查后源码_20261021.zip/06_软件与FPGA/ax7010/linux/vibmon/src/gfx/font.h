#pragma once

#include <cstdint>
#include <string>

#include "gfx/canvas.h"

namespace vm {

// Pre-rendered 4-bit anti-aliased glyphs (tools/gen_font.py, Noto Sans SC,
// SIL OFL 1.1). Only characters that appear in the UI/report sources plus
// printable ASCII are included.
struct FontGlyph {
  uint32_t codepoint;
  uint8_t w, h;
  int8_t xoff, yoff;  // from pen position (x) and from the top of the line box (y)
  uint8_t advance;
  uint32_t offset;    // into the face bitmap, 2 pixels per byte (high nibble first)
};

struct FontFace {
  int pixelSize;
  int lineHeight;
  int ascent;
  const FontGlyph* glyphs;
  int count;
  const uint8_t* bitmap;
};

const FontFace& fontFace(int pixelSize);  // nearest generated size
int textWidth(const FontFace& f, const std::string& utf8);
// Draws with the top-left corner of the line box at (x, y); returns the end x.
int drawText(Canvas& c, const FontFace& f, int x, int y, const std::string& utf8, uint32_t color);
int drawTextCentered(Canvas& c, const FontFace& f, int cx, int y, const std::string& utf8, uint32_t color);
uint32_t nextCodepoint(const std::string& s, size_t& i);

}  // namespace vm
