// Renders the touch UI and a printed slip off-screen. With an output
// directory argument the images are written as PPM for visual review.
#include <cmath>
#include <cstring>
#include <cstdio>
#include <string>

#include "app/report.h"
#include "gfx/font.h"
#include "test_util.h"
#include "ui/fb_ui.h"

using namespace vm;

namespace {

void writePpm(const Canvas& c, const std::string& path) {
  FILE* f = fopen(path.c_str(), "wb");
  if (!f) return;
  fprintf(f, "P6\n%d %d\n255\n", c.width(), c.height());
  for (int y = 0; y < c.height(); ++y) {
    for (int x = 0; x < c.width(); ++x) {
      const uint32_t p = c.get(x, y);
      const unsigned char rgb[3] = {static_cast<unsigned char>(p >> 16), static_cast<unsigned char>(p >> 8),
                                    static_cast<unsigned char>(p)};
      fwrite(rgb, 1, 3, f);
    }
  }
  fclose(f);
}

}  // namespace

int main(int argc, char** argv) {
  const std::string out = argc > 1 ? argv[1] : "";

  // Hit-testing must agree with visible availability and with the current capture state.
  SystemState controls;
  controls.cameraOk = true;
  controls.measureState = "preview";
  CHECK(jStr(FbUi::tapCommand(700, 370, controls), "cmd", "") == "measure_start");
  CHECK(FbUi::tapCommand(900, 370, controls).isNull());  // no saved record
  controls.last.have = controls.last.saved = true;
  CHECK(jStr(FbUi::tapCommand(900, 370, controls), "cmd", "") == "print");
  controls.measureState = "capturing";
  CHECK(jStr(FbUi::tapCommand(700, 370, controls), "cmd", "") == "measure_stop");
  CHECK(FbUi::tapCommand(900, 370, controls).isNull());
  CHECK(FbUi::tapCommand(328, 228, controls).isNull());  // no ROI changes during capture
  controls.measureState = "analyzing";
  CHECK(FbUi::tapCommand(700, 370, controls).isNull());
  controls.measureState = "preview";
  controls.printerState = "printing";
  controls.lightAllowed = true;
  CHECK(FbUi::tapCommand(700, 370, controls).isNull());
  CHECK(FbUi::tapCommand(700, 450, controls).isNull());
  controls.printerState = "idle";
  controls.zoom = 2;
  const auto roiCmd = FbUi::tapCommand(8, 48, controls);
  CHECK(jStr(roiCmd, "cmd", "") == "roi");
  CHECK_NEAR(jNum(roiCmd, "x", 0), 0.25, 1e-9);
  CHECK_NEAR(jNum(roiCmd, "y", 0), 0.25, 1e-9);
  controls.shutdownPrepared = true;
  CHECK(FbUi::tapCommand(700, 370, controls).isNull());
  CHECK(FbUi::tapCommand(900, 540, controls).isNull());

  // Every glyph used by the UI must exist in the generated font.
  const FontFace& f26 = fontFace(26);
  for (const char* s : {"开始测量", "打印报告", "补光 开", "报警静音", "缩放复位", "关机", "视觉测振报告", "未判级", "应用已停止, 等待Linux关机", "应用已停止, Linux仍在运行"}) {
    std::string str(s);
    for (size_t i = 0; i < str.size();) {
      const uint32_t cp = nextCodepoint(str, i);
      bool found = false;
      for (int k = 0; k < f26.count; ++k) found = found || f26.glyphs[k].codepoint == cp;
      CHECK(found);
    }
  }

  SystemState s;
  s.initDone = true;
  s.timeValid = true;
  s.nanoOnline = true;
  s.wifiState = "CONNECTED";
  s.power.busV = 12.05;
  s.power.currentA = 2.31;
  s.pointId = "P-01";
  s.lightAllowed = true;
  s.lightOn = true;
  s.cameraOk = true;
  s.envValid = true;
  s.tempC = 24.6;
  s.rhPercent = 48;
  s.distanceValid = true;
  s.distanceMm = 512;
  s.measureState = "capturing";
  s.measureElapsedS = 3.4;
  s.measureDurationS = 10;
  s.message = "测量中...";
  s.zoom = 1.5;
  s.last.have = true;
  s.last.valid = true;
  s.last.unit = "mm";
  s.last.dominantHz = 12.48;
  s.last.peakToPeak = 0.1234;
  s.last.rms = 0.0431;
  s.last.level = AlarmLevel::kWarn;
  s.alarmLevel = AlarmLevel::kWarn;
  s.last.measurementId = "vibmon-01-20261020-130709";
  MeasurementEngine::Live live;
  live.cameraOk = true;
  live.previewW = 320;
  live.previewH = 180;
  live.frameW = 1280;
  live.frameH = 720;
  live.roi.x = 608;
  live.roi.y = 328;
  live.roi.w = live.roi.h = 64;
  live.preview.resize(320 * 180);
  for (int y = 0; y < 180; ++y)
    for (int x = 0; x < 320; ++x) live.preview[y * 320 + x] = static_cast<uint8_t>((x * 3 + y * 5) & 0xFF);
  for (int i = 0; i < 400; ++i) live.recent.push_back(static_cast<float>(2 * std::sin(i * 0.25)));
  Canvas ui(1024, 600);
  FbUi::render(ui, s, live, 0, 480);
  CHECK(ui.get(10, 10) != 0);

  ReportData d;
  d.deviceId = "vibmon-01";
  d.measurementId = s.last.measurementId;
  d.timeText = "2026-10-20T05:07:09.000Z";
  d.pointText = "P-01 电机A";
  d.summary = s.last;
  d.summary.peak = 0.061;
  d.calibrationText = "CAL-01";
  d.fps = 59.9;
  d.dropped = 0;
  d.envText = "环境 24.6 °C  48 %RH";
  for (int i = 0; i < 600; ++i) {
    d.t.push_back(i / 60.0);
    d.disp.push_back(0.06 * std::sin(2 * M_PI * 12.48 * i / 60.0));
  }
  for (int k = 0; k < 256; ++k) {
    d.f.push_back(k * 0.1);
    d.amp.push_back(0.061 * std::exp(-std::pow((k * 0.1 - 12.48) / 0.3, 2)));
  }
  Canvas slip = renderReport(d, 384);
  CHECK(slip.width() == 384 && slip.height() > 400);
  int wb = 0;
  std::vector<uint8_t> bits = toMonoBits(slip, wb);
  CHECK(wb == 48 && bits.size() == static_cast<size_t>(48 * slip.height()));

  SystemState preparing = s;
  preparing.shutdownPrepared = true;
  preparing.message = "应用已停止, 等待Linux关机";
  Canvas pending(1024, 600), osRunning(1024, 600);
  FbUi::render(pending, preparing, live, 0, 480);
  preparing.message = "应用已停止, Linux仍在运行";
  FbUi::render(osRunning, preparing, live, 0, 480);
  CHECK(std::memcmp(pending.data(), osRunning.data(), 1024 * 600 * sizeof(uint32_t)) != 0);

  if (!out.empty()) {
    writePpm(pending, out + "/shutdown_pending.ppm");
    writePpm(osRunning, out + "/shutdown_os_running.ppm");
    writePpm(ui, out + "/ui.ppm");
    writePpm(slip, out + "/report.ppm");
    printf("wrote %s/ui.ppm and report.ppm\n", out.c_str());
  }
  return testSummary("render");
}
