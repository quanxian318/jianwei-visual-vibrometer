# 06_软件与FPGA

按 09_团队开发资料_20261020 的引脚表、协议 V1 和开发说明编写。三部分共用 `shared/vibproto`（协议 V1 帧编解码、CRC、严格 JSON，C++11）。

当前代码逻辑、审查结论与待实现项见 [代码审查与状态机说明](docs/代码审查与状态机说明_20261021.html)（[Markdown](docs/代码审查与状态机说明_20261021.md)）。当前测振为 PS 单 ROI 软件基线，PL 视觉位移核和视频放大链尚未实现。

[屏幕、触屏和编码器操作说明](docs/UI与触屏编码器说明_20261021.md)。

## 目录与验证状态

| 路径 | 内容 | 已验证 | 未验证 |
|---|---|---|---|
| shared/vibproto | 协议 V1 编解码 | 资料包 4 个测试向量逐字节一致；Python 参考实现生成的 300 个随机帧编码/解码/再序列化一致 | — |
| nano_esp32/vibmon_nano | Nano ESP32 固件：AX 链路与会话、事件队列/IRQ、PN532、SD、I2S 语音、Wi-Fi/NTP、掉电、USB 调试命令 | 本轮修改的 power_service/audio_service 已用真实 Xtensa 板包参数编译无警告；WAV 解析主机测试通过 | 修改后整包重新链接、上板；bin 保留旧固件 |
| ax7010/pl | carrier_ctrl RTL、Vivado 集成脚本、约束、自检测试平台 | WSL Icarus 行为仿真通过：AXI 分离握手/背压/WSTRB、PWM、按键、事件 FIFO、WS2812、看门狗 | Vivado 综合、实现、上板 |
| ax7010/linux/vibmon | AX7010 Linux 程序 vibmond、命令行 vibmonctl、联调工具 carrier_test | WSL x86-64（g++ 13）编译无警告；协议客户端对模拟 Nano、驱动对模拟寄存器、测量链对合成画面、界面/报告渲染、串口取消、19 项应用集成检查、端到端冒烟测试 | ARM 交叉编译、上板 |
| ax7010/linux/petalinux | 设备树片段、内核配置、Yocto 配方、开机自启 | 源码包可独立编译 | 在 PetaLinux 工程中构建 |

## Nano ESP32 固件

板包选 Arduino ESP32 Boards（arduino:esp32:nano_nora），Pin Numbering 用默认的 By Arduino pin。命令行构建：

```powershell
powershell -ExecutionPolicy Bypass -File nano_esp32\build_nano.ps1
```

**当前 bin 是本轮修改前的固件；本轮只完成两个修改源文件的目标编译，使用新保护逻辑须先运行完整构建。**

脚本把源码复制到 ASCII 临时目录，并用临时目录联接缩短板包路径（否则 ESP32 工具链的编译命令超过 Windows 32K 上限），不修改已安装的板包；产物在 `nano_esp32/bin`。用 Arduino IDE 打开时，先把 `shared/vibproto` 复制到 文档\Arduino\libraries，再按常规方式上传。

USB 串口命令：`status`、`events`、`sd`、`nfc`、`play <asset_id> [音量]`、`stop`、`wifi <ssid> [密码]`、`wifi off`、`baud <速率>`、`flow on|off`、`log <级别>`、`reboot`。波特率和流控保存在 NVS，重启生效，两端必须一致。AX 侧 UART16550 用 100 MHz 时钟时 921600 实际为 892857（误差 3.1%），高速档建议两端都用 781250（分频整除）。

协议实现的补充约定：Nano 启动产生 BOOT 事件；会话建立后才主动推送事件；HELLO 总是开启新会话并停止旧会话的语音；不在缓存窗口内且不大于已用 seq 的请求返回 SEQ_CONFLICT；HELLO 响应的 event_cursor 为 {last_event_id, acked_through, pending}；AUDIO_DONE 的 result 为 completed/stopped，异常结束用 AUDIO_FAILED；SET_NET 的 ssid 为空表示关闭 Wi-Fi。

## AX7010 PL：carrier_ctrl

集成步骤（Vivado 不能用中文路径，先把 `ax7010/pl` 复制到 ASCII 目录）：

1. 打开与板卡修订匹配、已能跑 AN5642/HDMI 的厂家工程和块设计。
2. Tcl 控制台：`source <路径>/bd/add_carrier.tcl`，再 `carrier::add`。脚本加入 carrier_ctrl（模块引用）、3×AXI IIC、2×AXI UART16550、1×AXI Quad SPI，按 XDC 端口名建外部端口，把 7 个中断追加到 IRQ_F2P，固定 AXI 地址（0x4400_0000 起），并写出 `bd/generated/carrier_map.json` 和 `carrier_generated.dtsi`。
3. 工程使用自动生成的顶层时重新 make_wrapper；手写顶层需要手工加入 34 个端口。Vivado 不支持模块引用 inout 端口时，把 IOBUF 移到顶层。
4. 综合实现，检查时序、I/O 约束和 CDC 报告，导出 XSA。

仿真：`ax7010/pl/sim/tb_carrier_ctrl.v` 是自检测试平台（AXI 读写、PWM 与掉电强制关断、事件时间戳、按键消抖、编码器、WS2812 位时序、看门狗），已在 WSL 的 Icarus Verilog 完整运行通过。可从任意目录用 `sh ax7010/pl/sim/run_tests.sh` 执行，或在 sim 目录运行：`iverilog -g2005 -o tb ../rtl/*.v IOBUF.v tb_carrier_ctrl.v && vvp tb`。

SPI 时钟按 FCLK 自动选不超过 1 MHz 的分频（100 MHz 时为 781 kHz）。复位后 PWM 和 WS_DATA 为低，片选为高。PFAIL_N 变低或看门狗超时时，PL 直接关闭两路补光 PWM；看门狗超时还会发送故障帧（HL101 红）。

| 偏移 | 名称 | 说明 |
|---|---|---|
| 0x000/004/008 | ID/VERSION/CLK_HZ | 0x56424331 / 0x00010000 / 时钟频率 |
| 0x010/014 | TS_LO/TS_HI | 读 TS_LO 时锁存 TS_HI |
| 0x020 | IN_RAW | [10:0] 事件源电平，[11] k1，[12] enc_sw，[13] A，[14] B |
| 0x024/028/02C | KEY_STATE/ENC_COUNT/ENC_ERRORS | 按下状态；×4 计数；非法跳变数 |
| 0x030/034/038 | DEBOUNCE_MS/LONG_MS/ENC_FILTER_US | 默认 15 / 3000 / 200 |
| 0x040–0x050 | PWM_PERIOD/DUTY0/DUTY1/CTRL/STATUS | CTRL[0][1] 使能，[4] 掉电强制关，[5] 看门狗强制关；STATUS 写 1 清除 |
| 0x060/064/068 | WDG_TIMEOUT_MS/KICK/STATUS | 0 = 关闭 |
| 0x080–0x0C0 | WS_CTRL/STATUS/RESET_US/COLOR0–4/FAULT0–4 | 颜色 0x00RRGGBB，HL101 为 0 号 |
| 0x100–0x12C | EVT_STATUS/INFO/TS_LO/TS_HI/POP/DROPPED/CLEAR/EN_RISE/EN_FALL/IRQ_CTRL/IRQ_STATUS | 事件 FIFO 512 项，每项带 64 位时间戳和序号 |

事件源编号：0 IMU_INT1，1 IMU_INT2，2 ADXL_DRDY，3 TOF_INT，4 RTC_1HZ，5 TACH_IN，6 PFAIL_N，7 EXP_INT_N，8 ESP_IRQ，9 PRN_CTS，10 ESP_CTS，16 K1 按下/松开，17 ENC_SW，18 K1 长按，19 ENC_SW 长按，20 编码器步进（level = 方向）。

## AX7010 Linux 程序

构建：PC 上 `make test` 编译并运行全部主机测试；目标板在 PetaLinux SDK 环境中 `make`（CXX/CXXFLAGS 由 SDK 提供）。`make integration-test` 运行应用状态机回归与合成相机端到端流程。

部署：把 `petalinux/recipes-apps/vibmon` 复制到 project-spec/meta-user/recipes-apps/，用 `tools/make_src_tarball.sh` 生成 `files/vibmon-src.tar.gz`，加入 rootfs。内核选项见 `petalinux/vibmon-kernel.cfg`。设备树按 `petalinux/system-user.dtsi` 合并，并在内核命令行追加 `uio_pdrv_genirq.of_id=vibmon,carrier-ctrl`。配方用 Yocto 新语法（`:${PN}`），PetaLinux 2021 及以前改为 `_${PN}`。

运行：`vibmond -c /etc/vibmon/vibmon.json`（模板 `config/vibmon.json`）。程序按 AXI 基地址在 sysfs 中找 /dev/i2c-N、ttyS、spidev 和 uio 节点，不写死设备号。标定文件 `/etc/vibmon/calibration.json`（模板 `config/calibration.example.json`），没有有效标定时结果以像素为单位并显示“未判级”；报警阈值只用于毫米结果。无效测量不会清除先前报警。

| 程序 | 用途 |
|---|---|
| vibmond | 主程序：板内管理、补光与报警、前面板与五灯、传感器、Nano 链路、测量与记录、打印、触摸界面 |
| vibmonctl | 本地控制：`status`、`measure_start duration_s=10`、`measure_stop`、`print`、`light on=true percent=80,80`、`mute`、`roi x=0.5 y=0.4`、`voice asset=measure_done`、`set_net ssid=… password=…`、`rtc_set unix_ms=…`、`shutdown` |
| carrier_test | 首板联调（先停 vibmond）：`probe`、`i2c-scan mgmt|sens`、`tca`、`load <名称> 0|1`、`power`、`rtc [set]`、`leds RRGGBB×5`、`pwm a b`、`events [秒]`、`imu`、`adxl`、`sht40`、`tof`、`nano [波特率]`、`printer [波特率]` |

测量记录：`records_dir/<测量编号>/record.json`（schema vision-vibration-record-1）、`waveform.csv`、`spectrum.csv`，有数据时还有 `imu.csv`、`reference_adxl345.csv`。打印内容从保存的记录生成。测量开始时冻结测点与照明；丢帧、无效采集时刻、低质量跟踪、搜索触边和饱和不再插值成有效结果。峰峰值和有效值取去线性趋势后的位移；频谱峰值为单边 0-峰值（Hann 窗，已做相干增益修正）。

VL53L1X 测距需要 ST 官方 ULD（STSW-IMG009）：把 `VL53L1X_api.c/.h`、`VL53L1X_calibration.c/.h` 放到 `ax7010/linux/vibmon/third_party/vl53l1x_uld/` 后重新编译；平台层已在 `src/drv/vl53l1x_uld_port`。没有 ULD 时只识别芯片型号，不输出距离。

中文字库由 `tools/gen_font.py`（需 Pillow，字体 Noto Sans SC，SIL OFL）按源码里出现的字符生成 `src/gfx/font_data.inc`；界面或报告新增中文后重新运行。

## 首板需要确认的事项

| 事项 | 影响 |
|---|---|
| 厂家工程的 AN5642 是否提供 V4L2 设备、像素格式与帧率 | `camera` 配置；不是 V4L2 时需按 FrameSource 接口接入 |
| EM5820H 该批次波特率、TTL 针序、CTS 极性、完成确认方式 | `printer` 配置（status_query、ms_per_raster_row、各等待时间） |
| GY-291 的 SDO/CS/供电与共享 SPI 资格测试 | 通过前保持 `adxl345.enabled=false` |
| Nano 链路实测波特率与流控 | 两端统一后再提速 |
| 打印启动电流、12 V 跌落、PFAIL 阈值 | 打印与负载策略参数 |
